import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class CaveBattle1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

public class CaveBattle1 extends World {
    private World previousWorld; // 1. Tambahkan variabel penyimpan World asal

    // Constructor bawaan yang sudah ada (biarkan saja)
    public CaveBattle1() {    
        super(900, 600, 1);
        
        addObject(new Bat(),770, 440);
        addObject(new Player(), 80, 480);
        //prepare();
    }

    public void act()
    {

    }
    
    
    // 2. TAMBAHKAN CONSTRUCTOR BARU INI agar error di trigger1 hilang
    public CaveBattle1(World previousWorld) {
        super(900, 600, 1);
        this.previousWorld = previousWorld;
        //prepare(); // Panggil method setup objek battle-mu (jika ada)
    }

    // Method untuk kembali ke CrystalCaveWorld setelah menang
    public void winBattle() {
        if (previousWorld != null) {
            Greenfoot.setWorld(previousWorld);
        }
    }
}
