import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class trigger2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

public class trigger2 extends AmbushZone {
    
    public trigger2() {
        super("caveEnemyEntry.png");
    }

    @Override
    public World createBattleWorld(World currentWorld) {
        return new CaveBattle1(currentWorld);
    }
}
