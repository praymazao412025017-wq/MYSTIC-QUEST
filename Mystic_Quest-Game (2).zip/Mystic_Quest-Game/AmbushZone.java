import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class AmbushZone here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

public abstract class AmbushZone extends Actor {
// Constructor menerima nama file gambar dari subclass
    public AmbushZone(String imageName) {
        GreenfootImage img = new GreenfootImage(imageName);
        
        // Opsional: hapus tanda '//' di bawah jika gambar PNG aslinya kebesaran/kekecilan
        // img.scale(40, 40); 
        
        setImage(img);
    }

    // Kontrak wajib bagi trigger1, trigger2, dan trigger3
    public abstract World createBattleWorld(World currentWorld);
}
