import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Bat here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Bat extends Actor
{
    private GreenfootImage normalImage;
    
    private int hp = 100;
    private int moveCounter = 0;
    private int direction = 1; // 1 = turun, -1 = naik
    private int delay = 0;     // Biar gerakannya tidak terlalu ngebut

    private int hitTimer = 0;
    private boolean hit = false;

    private int startX;
    private int startY;

    /**
     * Act - do whatever the Bat wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    public Bat()
    {
        normalImage = new GreenfootImage("bat.png");

        normalImage.scale(145, 105);

        setImage(new GreenfootImage(normalImage));
    }

    
    public void takeDamage()
    {
        if (!hit)
        {
            hit = true;
            hitTimer = 0;

            startX = getX();
            startY = getY();
        }
    }
    
    private void idleMove() {
        delay++;
        if (delay % 3 == 0) { // Bergerak setiap 2 frame agar lebih halus
            setLocation(getX(), getY() + direction);
            moveCounter++;

            // Jika sudah bergerak 15 langkah, balik arah
            if (moveCounter >= 12) {
                direction = -direction; 
                moveCounter = 0;
            }
        }
    }
    
    public void act()
    {
        if (hp > 0) {
            idleMove();
        }
        
        if (hit)
        {
            hitTimer++;

            // Monster mundur
            if (hitTimer <= 5)
            {
                setLocation(startX + 4, startY);
            }

            // Monster kembali
            else if (hitTimer <= 10)
            {
                setLocation(startX, startY);
            }

            // Efek berkedip
            if (hitTimer % 3 == 0)
            {
                GreenfootImage flash =
                    new GreenfootImage(normalImage);

                flash.setColor(new Color(255, 50, 50, 150));
                flash.fill();

                setImage(flash);
            }
            else
            {
                setImage(new GreenfootImage(normalImage));
            }

            if (hitTimer >= 15)
            {
                hit = false;
                setLocation(startX, startY);
                setImage(new GreenfootImage(normalImage));
            }
        }
    }
    
    public void shootPoison()
    {
        if (getWorld() != null)
        {
            Poison poison = new Poison();
    
            getWorld().addObject(
                poison,
                getX() - 60,
                getY()
            );
        }
    }
        
}
