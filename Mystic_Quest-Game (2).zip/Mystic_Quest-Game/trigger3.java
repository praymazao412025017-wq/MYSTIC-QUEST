import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class trigger3 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

public class trigger3 extends AmbushZone {
    
    public trigger3() {
        super("caveBossEntry.png");
    }

    @Override
    public World createBattleWorld(World currentWorld) {
        return new CaveBattle1(currentWorld);
    }
}

