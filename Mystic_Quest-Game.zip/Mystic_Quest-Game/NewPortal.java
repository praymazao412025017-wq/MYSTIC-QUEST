import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class CavePortal here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

public class NewPortal extends Actor
{
    // Array untuk menyimpan 4 gambar frame portal
    private GreenfootImage[] frames = new GreenfootImage[4];
    
    // Variabel untuk melacak frame ke berapa yang sedang aktif (0 sampai 3)
    private int currentFrame = 0;
    
    // Timer untuk mengatur kecepatan animasi agar tidak terlalu cepat
    private int animationTimer = 0;
    private int animationSpeed = 40; // Semakin kecil angka ini, semakin cepat putarannya

    public NewPortal()
    {
        // Memuat 4 gambar ke dalam array
        // (Pastikan nama file sesuai dengan yang ada di folder images kamu)
        frames[0] = new GreenfootImage("Portal1.png");
        frames[1] = new GreenfootImage("Portal2.png");
        frames[2] = new GreenfootImage("Portal3.png");
        frames[3] = new GreenfootImage("Portal4.png");
        
        // Set gambar awal saat portal pertama kali muncul
        setImage(frames[0]);
    }

    public void act()
    {
        animatePortal();
    }
    
    private void animatePortal()
    {
        animationTimer++;
        
        // Jika timer mencapai batas kecepatan, ganti frame-nya
        if (animationTimer >= animationSpeed)
        {
            animationTimer = 0; // Reset timer
            currentFrame = (currentFrame + 1) % frames.length; // Pindah ke frame berikutnya (loop 0->1->2->3->0...)
            
            // Terapkan gambar baru ke aktor
            setImage(frames[currentFrame]);
        }
    }
}